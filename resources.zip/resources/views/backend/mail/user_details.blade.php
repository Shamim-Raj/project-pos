<h1>Your Username : {{$user_data['name']}}</h1>
<h1>Your Password : {{$user_data['password']}}</h1>
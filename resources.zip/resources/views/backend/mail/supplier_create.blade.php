<h1>Congratulation {{$supplier_data['name']}}!</h1>
<h3>Hope that our deal will be prosperous</h3>
<p>Thank you</p>
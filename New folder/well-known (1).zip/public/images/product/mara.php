<?php

echo 'mara kha';

?>
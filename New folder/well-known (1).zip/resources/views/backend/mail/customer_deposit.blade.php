<h1>Hey {{$deposit_data['name']}}!</h1>
<h3>{{$deposit_data['currency']}} {{$deposit_data['amount']}} has successfully recharged in your account.</h3>
<p>Your current balance is: {{$deposit_data['balance']}}</p>
<p>Thank you</p>